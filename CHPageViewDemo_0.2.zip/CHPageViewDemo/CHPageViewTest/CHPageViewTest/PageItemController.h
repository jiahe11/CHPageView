//
//  PageItemController.h
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2019/1/2.
//  Copyright © 2019 HOWZ_MINI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHPageViewProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface PageItemController : UIViewController<CHPageViewProtocol>

@property (nonatomic,strong) UIColor * backColor;
@property (nonatomic,assign) int tag;

//@property (nonatomic,copy) CGFloat(^scrollViewScrollBlock)(CGFloat offset);

@end

NS_ASSUME_NONNULL_END
