//
//  NoScrollViewController.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2019/1/4.
//  Copyright © 2019 HOWZ_MINI. All rights reserved.
//

#import "NoScrollViewController.h"

@interface NoScrollViewController ()
@property (nonatomic,strong) UILabel * titleLabel;
@end

@implementation NoScrollViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UILabel * lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width , 40)];
    [self.view addSubview:lable];
    lable.font = [UIFont boldSystemFontOfSize:20];
    lable.textColor = UIColor.blueColor;
    lable.text = [NSString stringWithFormat:@"这是scrollView"];
    lable.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    lable.textAlignment = NSTextAlignmentCenter;
    self.view.backgroundColor = [UIColor whiteColor];
    self.titleLabel = lable;
    
    UIImageView * imageView  = [[UIImageView alloc] init];
    [self.view addSubview:imageView];
    imageView.frame = CGRectMake(0, 0, 100, 100);
//    imageView.image = [UIImage imageNamed:@"timg"];
    imageView.layer.cornerRadius = 30;
    imageView.backgroundColor = [UIColor redColor];
    
    
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.titleLabel.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
