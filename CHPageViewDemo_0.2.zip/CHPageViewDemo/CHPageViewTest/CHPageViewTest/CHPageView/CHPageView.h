//
//  CHPageView.h
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2018/12/28.
//  Copyright © 2018 HOWZ_MINI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHPageViewProtocol.h"

typedef NS_ENUM(NSInteger,CHPageViewType) {
    CHPageViewTypeDefault = 0,
    CHPageViewTypeTopScroll
};

//NS_ASSUME_NONNULL_BEGIN

@interface CHPageView : UIView

@property (nonatomic,strong) UIView * headerView;
@property (nonatomic,strong) UIImageView * topScrollLine;
@property (nonatomic,strong) UIScrollView * scrollView;
@property (nonatomic,strong) UIScrollView * topBarScroll;
@property (nonatomic, strong) UIFont *font; // 标题的字体
@property (nonatomic,weak) UIViewController * currentVC;// 当前子视图的控制器
@property (nonatomic,weak) UIViewController * superVC;// 父视图的控制器
@property (nonatomic,assign) NSInteger currentPage;
@property (nonatomic,assign) NSInteger defaultPage; // 初始化的时候的页码
@property (nonatomic,strong) NSMutableArray * itemBtnArray; // 宽度数组
@property (nonatomic,strong) NSMutableArray * titleArray; // 标题数组
@property (nonatomic,strong) NSMutableArray * dataArray; // 参数数组
@property (nonatomic,strong) NSMutableArray * centerPoints; // 按钮中心点数组
@property (nonatomic,strong) NSMutableArray * itemWidthArrs; // 宽度数组
@property (nonatomic,assign) CGFloat minSpace;// 按钮文字左右的宽度

@property (nonatomic,assign) CGRect pageFrame;

// 头部是否根据内容划动
@property (nonatomic,assign) CHPageViewType pageType; // 默认为L：CHPageViewTypeDefault 不划动

@property (nonatomic,strong) NSMutableArray * controllers;
@property (nonatomic,strong) void(^pageChangeBlock)(NSInteger itemPage,UIViewController * vc);
- (void)configureControllers:(NSMutableArray *)controllers andTitleArray:(NSMutableArray *)titleArray andParams:(NSMutableArray * )dataArray;

@end

//NS_ASSUME_NONNULL_END
