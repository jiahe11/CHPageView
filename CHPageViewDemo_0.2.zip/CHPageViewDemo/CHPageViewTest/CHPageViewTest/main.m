//
//  main.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2018/12/28.
//  Copyright © 2018 HOWZ_MINI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
