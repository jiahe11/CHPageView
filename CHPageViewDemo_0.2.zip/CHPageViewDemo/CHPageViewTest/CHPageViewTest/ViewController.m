//
//  ViewController.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2018/12/28.
//  Copyright © 2018 HOWZ_MINI. All rights reserved.
//

#import "ViewController.h"
#import "CHPageView.h"
#import "PageItemController.h"
#import "NoScrollViewController.h"

@interface ViewController ()

@property (nonatomic,strong) CHPageView * pageView;
@property (nonatomic,strong) UIView * headerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pageView = [[CHPageView alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-20)];
    
    [self.view addSubview:self.pageView];
    self.pageView.defaultPage = 1;
     // 设置头部可以跟着内容上划
    self.pageView.pageType = CHPageViewTypeTopScroll;
    
    UIButton * btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 120)];
    self.headerView = btn;
    self.headerView.backgroundColor = [UIColor redColor];
    self.pageView.headerView = self.headerView;
    [btn addTarget:self action:@selector(headerBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    
}

- (void)headerBtnAction:(UIButton *)btn {
    
    NSMutableArray * arr = [[NSMutableArray alloc] init];
    NSMutableArray * titleArr = [[NSMutableArray alloc] init];
    
    self.pageView.layer.borderWidth = 1;
    static int num = 0;
    num++;
    for (int i = 0; i < num; i++) {
        if(i % 2 == 0) {
            NoScrollViewController * itemVC  = [[NoScrollViewController alloc] init];
            [arr addObject:itemVC];
            [titleArr addObject:[NSString stringWithFormat:@"item %d_%d",i,i]];
        } else {
            PageItemController * itemVC  = [[PageItemController alloc] init];
            itemVC.tag = i+1;
            [arr addObject:itemVC];
            [titleArr addObject:[NSString stringWithFormat:@"item %d_%d",i,i]];
        }
        
        
    }
    self.pageView.defaultPage = num/3;
    [self.pageView configureControllers:arr andTitleArray:titleArr andParams:nil];
}


@end
