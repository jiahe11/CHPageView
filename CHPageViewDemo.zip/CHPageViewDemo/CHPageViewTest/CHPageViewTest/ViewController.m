//
//  ViewController.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2018/12/28.
//  Copyright © 2018 HOWZ_MINI. All rights reserved.
//

#import "ViewController.h"
#import "CHPageView.h"
#import "PageItemController.h"
#import "NoScrollViewController.h"

@interface ViewController ()

@property (nonatomic,strong) CHPageView * pageView;
@property (nonatomic,strong) UIView * headerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pageView = [[CHPageView alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-20)];
    NSMutableArray * arr = [[NSMutableArray alloc] init];
    NSMutableArray * titleArr = [[NSMutableArray alloc] init];
    self.pageView.layer.borderWidth = 1;
    for (int i = 0; i < 8; i++) {
        if(i < 2) {
            NoScrollViewController * itemVC  = [[NoScrollViewController alloc] init];
            [arr addObject:itemVC];
            [titleArr addObject:[NSString stringWithFormat:@"item %d_%d",i,i]];
        } else {
            PageItemController * itemVC  = [[PageItemController alloc] init];
            itemVC.tag = i+1;
            [arr addObject:itemVC];
            [titleArr addObject:[NSString stringWithFormat:@"item %d_%d",i,i]];
        }
        
        
    }
    [self.pageView configureControllers:arr andTitleArray:titleArr andParams:nil];
    [self.view addSubview:self.pageView];
    self.pageView.defaultPage = 1;
     // 设置头部可以跟着内容上划
    self.pageView.pageType = CHPageViewTypeTopScroll;
    
    self.headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 120)];
    self.headerView.backgroundColor = [UIColor redColor];
    self.pageView.headerView = self.headerView;
}


@end
