//
//  PageItemController.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2019/1/2.
//  Copyright © 2019 HOWZ_MINI. All rights reserved.
//

#import "PageItemController.h"

@interface PageItemController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView * tableView;
@property (nonatomic,strong) UILabel * titleLabel;
@property (nonatomic,strong) UIButton * addBtn;

@end

@implementation PageItemController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UILabel * lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width , 40)];
    [self.view addSubview:lable];
    lable.font = [UIFont boldSystemFontOfSize:20];
    lable.textColor = UIColor.blueColor;
    lable.text = [NSString stringWithFormat:@"这是第 %d 页",self.tag];
    lable.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    lable.textAlignment = NSTextAlignmentCenter;
    if(self.backColor) {
        self.view.backgroundColor = self.backColor;
    } else {
        self.view.backgroundColor = [UIColor whiteColor];
    }
    self.titleLabel = lable;
    
    self.tableView = [[UITableView alloc] init];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    UIButton * btn = [[UIButton alloc] initWithFrame:self.titleLabel.frame];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(btnAction) forControlEvents:UIControlEventTouchUpInside];
    self.addBtn = btn;
    
}

- (void)btnAction {
    self.tableView.contentOffset = CGPointMake(0, self.tableView.contentOffset.y + 1);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.titleLabel.frame = CGRectMake(0, 0, self.view.frame.size.width , 40);
    self.tableView.frame = CGRectMake(0, CGRectGetMaxY(self.titleLabel.frame),self.view.frame.size.width, self.view.frame.size.height-CGRectGetMaxY(self.titleLabel.frame));
    self.addBtn.frame = self.titleLabel.frame;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"index = %ld_%ld",indexPath.row,indexPath.row];
    
    return cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
//    if(self.scrollViewScrollBlock) {
//        CGFloat offsetY = self.scrollViewScrollBlock(scrollView.contentOffset.y);
//        if(offsetY == 0) {
//            self.tableView.contentOffset = CGPointZero;
//        }
////        self.tableView.contentOffset = CGPointMake(0, offsetY);
//    }
}

- (UIScrollView *)gainViewScrollView {
    return self.tableView;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
