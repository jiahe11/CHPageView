//
//  CHPageView.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2018/12/28.
//  Copyright © 2018 HOWZ_MINI. All rights reserved.
//

#import "CHPageView.h"
#import <objc/runtime.h>

@interface CHPageView ()<UIScrollViewDelegate>

@property (nonatomic,strong) NSMutableArray * parameters;
@property (nonatomic,assign) CGFloat offsetNow;

@end

@implementation CHPageView

- (void)dealloc {
    //NSLog(@"%@",self.class);
//    [self removeObserver:self forKeyPath:@"currentPage"];
    if([self.currentVC respondsToSelector:@selector(gainViewScrollView)]) {
        id obj = self.currentVC;
        UIScrollView * scroll = [obj gainViewScrollView];
        if(scroll && [scroll isKindOfClass:[UIScrollView class]]) {
            [scroll removeObserver:self forKeyPath:@"contentOffset"];
        }
    }
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.pageFrame = frame;
        self.minSpace = 10;
        self.font = [UIFont systemFontOfSize:15];
        [self makeView];
        if (@available(iOS 11.0, *)) {
            [[UIScrollView appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
        } else {
            [[self findViewController:self] setAutomaticallyAdjustsScrollViewInsets:NO];
        }
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self initTopBarView];
    
}

-(void)makeView {
    
    
    [self setHeaderView:nil];
//    self.currentPage = self.defaultPage;
    [self.topBarScroll addSubview:self.topScrollLine];
    self.topScrollLine.frame = CGRectMake(0, self.topBarScroll.frame.size.height-3, 0, 3);
    
}

- (void)refreshTopBarFrame:(CGRect)frame {
    
    
    
}

- (void)setHeaderView:(UIView *)headerView {
    if(headerView == nil) {
        [_headerView removeFromSuperview];
    }
    _headerView = headerView;
    if(_headerView == nil) {
        self.topBarScroll.frame = CGRectMake(0, 0, self.pageFrame.size.width, 44);
        [self addSubview:self.topBarScroll];
        
        self.scrollView.frame = CGRectMake(0, CGRectGetMaxY(self.topBarScroll.frame), self.pageFrame.size.width, self.pageFrame.size.height-CGRectGetMaxY(self.topBarScroll.frame));
        [self addSubview:self.scrollView];
    } else {
        
        [self addSubview:_headerView];
        CGRect headerFrame = _headerView.frame;
        headerFrame.origin.x = 0;
        headerFrame.origin.y = 0;
        _headerView.frame = headerFrame;
        
        self.topBarScroll.frame = CGRectMake(0, CGRectGetMaxY(_headerView.frame), self.pageFrame.size.width, 44);
        [self addSubview:self.topBarScroll];
        
        self.scrollView.frame = CGRectMake(0, CGRectGetMaxY(self.topBarScroll.frame), self.pageFrame.size.width, self.pageFrame.size.height-CGRectGetMaxY(self.topBarScroll.frame));
        [self addSubview:self.scrollView];
        self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * self.controllers.count, self.scrollView.frame.size.height);
        
    }
}

- (void)setCurrentPage:(NSInteger)currentPage {
    
    id obj = self.controllers[_currentPage];
    if(self.headerView&&self.pageType == CHPageViewTypeTopScroll) {
        
        if([obj respondsToSelector:@selector(gainViewScrollView)]) {
            
//            [obj setScrollViewScrollBlock:nil];
            // 移除监听
            UIScrollView * scroll = [obj gainViewScrollView];
            if(scroll && [scroll isKindOfClass:[UIScrollView class]]) {
                [scroll removeObserver:self forKeyPath:@"contentOffset"];
            }
        }
        
    }
    
    
    _currentPage = currentPage;
    [self topScrollItemAnimation:currentPage];
    
    // 刷新按钮视图
    [self updateSelectedPage:self.currentPage];
    
    //        [self addObserver:self forKeyPath:@"currentPage" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];
    
    
    self.currentVC = self.controllers[currentPage];
    
    //     添加监听
    if(self.headerView&&self.pageType == CHPageViewTypeTopScroll) {
        obj = self.currentVC;
        if([obj respondsToSelector:@selector(gainViewScrollView)]) {
            UIScrollView * scroll = [obj gainViewScrollView];
            [scroll addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];
            
        } else {
            if(self.headerView.frame.origin.y < 0) {
                [self refreshViewsLayout:self.headerView.frame.origin.y andAnimation:YES];
            }
        }
//        if([obj respondsToSelector:@selector(gainViewScrollView)]) {
//
//            UIScrollView * scroll = [obj gainViewScrollView];
//            if(scroll && [scroll isKindOfClass:[UIScrollView class]]) {
//                self.offsetNow = scroll.contentOffset.y;
//            }
//        }
//
//        __weak typeof(self) weakSelf = self;
//
//        if([obj respondsToSelector:@selector(setScrollViewScrollBlock:)]&&self.pageType == CHPageViewTypeTopScroll) {
//
//            [obj setScrollViewScrollBlock:^CGFloat(CGFloat offset) {
////                NSLog(@"weakSelf.offsetNow %lf ,  offset = %f",weakSelf.offsetNow,offset);
//                int tag = 1;
//
//                if(weakSelf.offsetNow > offset) {
//                    //下拉
//                    if(offset <= 0.0) {
//                        if(weakSelf.headerView.frame.origin.y < 0) {
//                            [weakSelf refreshViewsLayout:offset];
//                            tag = 0;
//                        }
//                    }
//                } else if(weakSelf.offsetNow < offset){
//                    // 上拉
//                    if(offset >= 0.0) {
//                        if(offset < 50) {// 目前测试这个值效果较好，bug问题较少
//                            if(CGRectGetMaxY(weakSelf.headerView.frame) > 0) {
//
//                                [weakSelf refreshViewsLayout:offset];
//                                tag = 0;
//                            }
//                        } else {
//                            if(CGRectGetMaxY(weakSelf.headerView.frame) > 0) {
//                                [weakSelf refreshViewsLayout:offset-weakSelf.offsetNow];
//                            }
//                        }
//
//                    }
//                }
//
//
//                weakSelf.offsetNow = offset;
//                return tag;
//
//
////                CGFloat oldOff = weakSelf.offsetNow;
////                if(weakSelf.offsetNow > offset) {
////                    // 向下拉，
////                    if(weakSelf.headerView.frame.origin.y < 0) {
////                        // header位置未还原
////                        [weakSelf refreshViewsLayout:offset - oldOff];
////                        weakSelf.offsetNow = offset;
////                        return oldOff;
////                    }
////                } else if(weakSelf.offsetNow < offset){
////                    // 向上拉，
////                    if(offset >= 0) {
////                        if(CGRectGetMaxY(weakSelf.headerView.frame) > 0) {
////                            // header还可见
////                            [weakSelf refreshViewsLayout:offset - oldOff];
////                            weakSelf.offsetNow = offset;
////                            return oldOff;
////                        }
////                    }
////                }
////                weakSelf.offsetNow = offset;
////                return offset;
//            }];
        
//        }
    }


    
}

// change为正值表示向上移动，，负值表示向下划动
- (void) refreshViewsLayout:(CGFloat)change andAnimation:(BOOL)isAnimation{
    
    if(change != 0) {// 等于0 不操作
        CGFloat animationTime = isAnimation?0.25:0;
        [UIView animateWithDuration:animationTime animations:^{
            CGRect headerFrame = self.headerView.frame;
            headerFrame.origin.y = headerFrame.origin.y - change;
            if(headerFrame.origin.y > 0) {
                headerFrame.origin.y = 0;
            } else if(headerFrame.origin.y < -self.headerView.frame.size.height) {
                headerFrame.origin.y = -self.headerView.frame.size.height;
            }
            self.headerView.frame = headerFrame;
            
            self.topBarScroll.frame = CGRectMake(0, CGRectGetMaxY(self.headerView.frame), self.pageFrame.size.width, 44);
            
            self.scrollView.frame = CGRectMake(0, CGRectGetMaxY(self.topBarScroll.frame), self.pageFrame.size.width, self.pageFrame.size.height-CGRectGetMaxY(self.topBarScroll.frame));
            self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * self.controllers.count, self.scrollView.frame.size.height);
        } completion:^(BOOL finished) {
            // 系统自动设置了，scrollView的控制器view自适应scrollView的大小，机制不清楚，下面目前不用写
//            CGRect rect = self.currentVC.view.frame;
//            rect.size.height = self.scrollView.frame.size.height;
//            self.currentVC.view.frame = rect;
        }];
        
        
    }
    
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"contentOffset"]) {
        if(self.headerView == nil&&self.pageType == CHPageViewTypeDefault) {
            return;
        }
        CGPoint offNew = [change[@"new"] CGPointValue];
        CGPoint offOld = [change[@"old"] CGPointValue];
        
//        int tag = 1;
        
        if(offOld.y > offNew.y) {
            // 下划动
            if(offNew.y <= 0.0) {
                if(self.headerView.frame.origin.y < 0) {
                    [self refreshViewsLayout:offNew.y andAnimation:NO];
                    id obj = self.currentVC;
                    UIScrollView * scroll = [obj gainViewScrollView];
                    if(scroll && [scroll isKindOfClass:[UIScrollView class]]) {
                        [scroll setContentOffset:CGPointZero];
                    }
//                    tag = 0;
                }
            }
        } else if(offOld.y < offNew.y){
            // 上划动
            if(offNew.y >= 0.0) {
                if(offNew.y < 50) {// 目前测试这个值效果较好，bug问题较少
                    if(CGRectGetMaxY(self.headerView.frame) > 0) {
                        
                        [self refreshViewsLayout:offNew.y andAnimation:NO];
//                        tag = 0;
                        id obj = self.currentVC;
                        UIScrollView * scroll = [obj gainViewScrollView];
                        if(scroll && [scroll isKindOfClass:[UIScrollView class]]) {
                            [scroll setContentOffset:CGPointZero];
                        }
                    }
                } else {
                    if(self.offsetNow != offNew.y) {
                        if(CGRectGetMaxY(self.headerView.frame) > 0) {
                            [self refreshViewsLayout:offNew.y-offOld.y andAnimation:NO];
                        }
                    }
                }
                
            }
        }
        
        // 在划动位移不为0的时候，偏移变化一次此方法调用多次，原因未知，所以记录值防止多次调用
        self.offsetNow = offNew.y;
        
    }
}
// 初始化头部bar视图 和 根据设置初始化视图
- (void)initTopBarView {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        CGFloat width = self.scrollView.frame.size.width;
        CGFloat height = self.scrollView.frame.size.height;
        
        CGFloat centerX = [self.centerPoints[self.defaultPage] floatValue];
        // 如果btn显示在中间 ,时间的偏移量是，中心点，剪去中心点到scrollview视图左边的距离
        CGFloat offset = centerX-self.topBarScroll.frame.size.width/2;  // 如果btn显示在中间，实际的需要的偏移量
        if(offset < 0) {
            // 最左边
            offset = 0;
            //            [self.topBarScroll setContentOffset:CGPointMake(0, 0) animated:YES];
        } else if(offset > self.topBarScroll.contentSize.width-self.topBarScroll.frame.size.width){
            // 最右边
            offset = self.topBarScroll.contentSize.width-self.topBarScroll.frame.size.width;
            //            [self.topBarScroll setContentOffset:CGPointMake(self.topBarScroll.contentSize.width-self.topBarScroll.frame.size.width, 0) animated:YES];
        }
        
        [self.topBarScroll setContentOffset:CGPointMake(offset, 0) animated:NO];
        CGRect rect = self.topScrollLine.frame;
        rect.size.width =  [self.titleArray[self.defaultPage] sizeWithAttributes:@{NSFontAttributeName:self.font}].width;
        self.topScrollLine.frame = rect;
        
        CGPoint lineCenter = self.topScrollLine.center;
        lineCenter.x = centerX;
        self.topScrollLine.center = lineCenter;
        
        UIViewController * vc = self.controllers[self.defaultPage];
        [self.scrollView addSubview:vc.view];
        vc.view.frame = CGRectMake(width*self.defaultPage, 0, width, height);
        
        self.currentPage = self.defaultPage;
        // 初始化位置
        [self.scrollView setContentOffset:CGPointMake(self.pageFrame.size.width * self.currentPage, 0) animated:NO];
    });
    
}

- (void)topScrollItemAnimation:(NSInteger)page {
    
    CGFloat width = self.scrollView.frame.size.width;
    CGFloat height = self.scrollView.frame.size.height;
    
    CGFloat centerX = [self.centerPoints[page] floatValue];
    // 如果btn显示在中间 ,时间的偏移量是，中心点，剪去中心点到scrollview视图左边的距离
    CGFloat offset = centerX-self.topBarScroll.frame.size.width/2;  // 如果btn显示在中间，实际的需要的偏移量
    if(offset < 0) {
        // 最左边
        offset = 0;
        //            [self.topBarScroll setContentOffset:CGPointMake(0, 0) animated:YES];
    } else if(offset > self.topBarScroll.contentSize.width-self.topBarScroll.frame.size.width){
        // 最右边
        offset = self.topBarScroll.contentSize.width-self.topBarScroll.frame.size.width;
        //            [self.topBarScroll setContentOffset:CGPointMake(self.topBarScroll.contentSize.width-self.topBarScroll.frame.size.width, 0) animated:YES];
    } else {
        //            // 中间任意位置
        //            [self.topBarScroll setContentOffset:CGPointMake(offset, 0) animated:YES];
    }
    [UIView animateWithDuration:0.25 animations:^{
        [self.topBarScroll setContentOffset:CGPointMake(offset, 0) animated:NO];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [UIView animateWithDuration:0.25 animations:^{
                CGRect rect = self.topScrollLine.frame;
                rect.size.width =  [self.titleArray[page] sizeWithAttributes:@{NSFontAttributeName:self.font}].width;
                self.topScrollLine.frame = rect;
                
                CGPoint lineCenter = self.topScrollLine.center;
                lineCenter.x = centerX;
                self.topScrollLine.center = lineCenter;
            }];
        });
    } completion:^(BOOL finished) {
    }];
    UIViewController * vc = self.controllers[page];
    [self.scrollView addSubview:vc.view];
    vc.view.frame = CGRectMake(width*page, 0, width, height);
    
}

#pragma mark delegateScrollView

-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if(self.scrollView == scrollView) {
        if (scrollView.contentOffset.x<=0 || scrollView.contentOffset.x >= self.pageFrame.size.width * (self.titleArray.count-1)) {
            return;
        }
        int page = (scrollView.contentOffset.x+self.pageFrame.size.width/2)/self.frame.size.width;
        if(self.currentPage != page) {
            self.currentPage = page;
            
        }
        
    } else if(self.topBarScroll){
        
    }
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
}

//-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
//    if(self.scrollView == scrollView) {
//        self.currentPage = (NSInteger)((scrollView.contentOffset.x + self.pageFrame.size.width / 2) / self.pageFrame.size.width);
//
//    } else if(self.topBarScroll){
//
//    }
//}
//
//// 减速结束
//- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
//    if(self.scrollView == scrollView) {
//        self.currentPage = (NSInteger)((scrollView.contentOffset.x + self.pageFrame.size.width / 2) / self.pageFrame.size.width);
//
//    } else if(self.topBarScroll){
//
//    }
//}

#pragma mark - 设置控制器和标题、参数等
- (void)configureControllers:(NSMutableArray *)controllers andTitleArray:(NSMutableArray *)titleArray andParams:(NSMutableArray *)dataArray {
    self.controllers = controllers;
    self.titleArray = titleArray;
    self.dataArray = titleArray;
    if(controllers != nil) {
        [controllers enumerateObjectsUsingBlock:^(UIViewController  * obj, NSUInteger idx, BOOL * _Nonnull stop) {
            UIViewController * superVC = [self findViewController:self];
            [superVC addChildViewController:obj];
            // 设置参数
            if (self.parameters && self.parameters.count > idx && self.parameters[idx] && [self getVariableWithClass:obj.class varName:@"parameter"]) {
                [obj setValue:self.parameters[idx] forKey:@"parameter"];
            }
            
        }];
    }
    
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * controllers.count, self.scrollView.frame.size.height);
    self.scrollView.contentOffset = CGPointMake(0, 0);
    NSMutableArray * equalArray = [[NSMutableArray alloc] init];
    CGFloat equalX = 0;
    CGFloat totalWidth = 0; // 总宽度
    CGFloat itemWidth = 0;  // 每个按钮的宽度
    NSMutableArray * itemWidthArr = [[NSMutableArray alloc] init]; // 每个item的宽度数组
    
    for(int i = 0 ;i < titleArray.count; i ++) {
        CGSize titleSize = [titleArray[i] sizeWithAttributes:@{NSFontAttributeName:self.font}];
//        [_titleSizeArray addObject:[NSValue valueWithCGSize:titleSize]];
        itemWidth = titleSize.width + self.minSpace*2;
        totalWidth += itemWidth ;
        [equalArray addObject:[NSNumber numberWithFloat:(equalX + itemWidth/2)]];
        equalX += itemWidth;
        [itemWidthArr addObject:[NSNumber numberWithFloat:itemWidth]];
    }
    if(totalWidth < self.topBarScroll.frame.size.width) {
        equalX = 0;
        [itemWidthArr removeAllObjects];
        NSMutableArray *averageArray = [NSMutableArray array];
        itemWidth = self.topBarScroll.frame.size.width/titleArray.count;
        totalWidth = self.topBarScroll.frame.size.width ;
        for(int i = 0 ;i < titleArray.count; i ++) {
            [averageArray addObject:[NSNumber numberWithFloat:equalX + itemWidth/2]];
            equalX += itemWidth;
            [itemWidthArr addObject:[NSNumber numberWithFloat:itemWidth]];
            
        }
        self.centerPoints = averageArray;
    } else {
        self.centerPoints = equalArray;
    }
    self.itemWidthArrs = itemWidthArr;
    // 制作按钮
    for(int i = 0;i < self.titleArray.count; i++) {
        CGFloat icx = [self.centerPoints[i] floatValue];
        CGFloat IW = [self.itemWidthArrs[i] floatValue];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.topBarScroll addSubview:btn];
        btn.tag = i;
        btn.frame = CGRectMake(icx-IW/2, 0, IW, self.topBarScroll.frame.size.height);
        [btn setTitle:self.titleArray[i] forState:UIControlStateNormal];
        [btn setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
        [btn setTitleColor:UIColor.redColor forState:UIControlStateSelected];
        [self.itemBtnArray addObject:btn];
        [btn addTarget:self action:@selector(itemBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    [self updateSelectedPage:self.defaultPage];
    
    self.topBarScroll.contentSize = CGSizeMake(totalWidth, self.topBarScroll.frame.size.height);
    
}

- (void)itemBtnAction:(UIButton *)button {
    [self.scrollView setContentOffset:CGPointMake(self.pageFrame.size.width * button.tag, 0) animated:YES];
}

-(void)setDefaultPage:(NSInteger)defaultPage {
    _defaultPage = defaultPage;
    
}

// 刷新按钮列表的显示
- (void)updateSelectedPage:(NSInteger)page {
    for (UIButton *button in self.itemBtnArray) {
        if (button.tag == page) {
            button.selected = YES;
//            [button setTitleColor:_selectedColor forState:UIControlStateNormal];
//            if (_isAnimated) {
//                [UIView animateWithDuration:0.3 animations:^{
//                    button.transform = CGAffineTransformMakeScale(1.1, 1.1);
//                }];
//            }
        }else{
            button.selected = NO;
//            [button setTitleColor:_unselectedColor forState:UIControlStateNormal];
//            if (_isAnimated) {
//                [UIView animateWithDuration:0.3 animations:^{
//                    button.transform = CGAffineTransformIdentity;
//                }];
//            }
        }
    }
}
//-(void)setControllers:(NSMutableArray *)controllers {
//
//
//}

// 获取pageView所在控制器
- (UIViewController *)findViewController:(UIView *)sourceView
{
    id target = sourceView;
    while (target) {
        target = ((UIResponder *)target).nextResponder;
        if ([target isKindOfClass:[UIViewController class]]) {
            break;
        }
    }
    return target;
}


#pragma mark getter

-(UIScrollView *)scrollView {
    if(!_scrollView) {
        
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.delegate = self;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.backgroundColor = [UIColor whiteColor];
        
//        [self addObserver:self forKeyPath:@"currentPage" options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];

    }
    return _scrollView;
}

-(UIScrollView *)topBarScroll {
    
    if(!_topBarScroll) {
        _topBarScroll = [[UIScrollView alloc] init];
        _topBarScroll.delegate = self;
        _topBarScroll.showsVerticalScrollIndicator = NO;
        _topBarScroll.showsHorizontalScrollIndicator = NO;
        _topBarScroll.backgroundColor = [UIColor whiteColor];

    }
    return _topBarScroll;
}

- (UIImageView *)topScrollLine {
    if(!_topScrollLine) {
        _topScrollLine = [[UIImageView alloc] init];
        _topScrollLine.backgroundColor = [UIColor redColor];
    }
    return _topScrollLine;
}

- (NSMutableArray *)itemBtnArray {
    if(!_itemBtnArray) {
        _itemBtnArray = [[NSMutableArray alloc] init];
    }
    return _itemBtnArray;
}

// 检测某个对象是否有每个方法
- (BOOL)getVariableWithClass:(Class)myClass varName:(NSString *)name {
    unsigned int outCount, i;
    Ivar *ivars = class_copyIvarList(myClass, &outCount);
    for (i = 0; i < outCount; i++) {
        Ivar property = ivars[i];
        NSString *keyName = [NSString stringWithCString:ivar_getName(property) encoding:NSUTF8StringEncoding];
        keyName = [keyName stringByReplacingOccurrencesOfString:@"_" withString:@""];
        if ([keyName isEqualToString:name]) {
            free(ivars);
            return YES;
        }
    }
    free(ivars);
    return NO;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
