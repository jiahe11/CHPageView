//
//  CHPageViewProtocol.m
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2019/1/3.
//  Copyright © 2019 HOWZ_MINI. All rights reserved.
//

#import "CHPageViewProtocol.h"
