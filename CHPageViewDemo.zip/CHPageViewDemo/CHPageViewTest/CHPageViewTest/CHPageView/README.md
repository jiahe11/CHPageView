##  PageView使用说明
1、如果CHPageView上控制起空间中有scrollView或其子类对象，并且想要头部视图根据内容划动，请控制器请尽可能的实现CHPageViewProtocol协议，并实现- (UIScrollView *)gainViewScrollView;方法，将scrollView返回回来，如果不想根据内容划动不实现，或者设置pageType属性为CHPageViewTypeDefault，默认是CHPageViewTypeDefault
基本使用方法
、、、
self.pageView = [[CHPageView alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-20)];
NSMutableArray * arr = [[NSMutableArray alloc] init];
NSMutableArray * titleArr = [[NSMutableArray alloc] init];
self.pageView.layer.borderWidth = 1;
for (int i = 0; i < 8; i++) {
if(i < 2) {
NoScrollViewController * itemVC  = [[NoScrollViewController alloc] init];
[arr addObject:itemVC];
[titleArr addObject:[NSString stringWithFormat:@"item %d_%d",i,i]];
} else {
PageItemController * itemVC  = [[PageItemController alloc] init];
itemVC.tag = i+1;
[arr addObject:itemVC];
[titleArr addObject:[NSString stringWithFormat:@"item %d_%d",i,i]];
}


}
[self.pageView configureControllers:arr andTitleArray:titleArr andParams:nil];
[self.view addSubview:self.pageView];
self.pageView.defaultPage = 1;
// 设置头部可以跟着内容上划
self.pageView.pageType = CHPageViewTypeTopScroll;

self.headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 120)];
self.headerView.backgroundColor = [UIColor redColor];
self.pageView.headerView = self.headerView;

