//
//  CHPageViewProtocol.h
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2019/1/3.
//  Copyright © 2019 HOWZ_MINI. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CHPageViewProtocol <NSObject>

@optional
//- (void)setScrollViewScrollBlock:(CGFloat(^)(CGFloat offset))scrollViewScrollBlock;
- (void)setParameter:(id)parameter;
- (UIScrollView *)gainViewScrollView;

@end

