//
//  NoScrollViewController.h
//  CHPageViewTest
//
//  Created by HOWZ_MINI on 2019/1/4.
//  Copyright © 2019 HOWZ_MINI. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NoScrollViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
